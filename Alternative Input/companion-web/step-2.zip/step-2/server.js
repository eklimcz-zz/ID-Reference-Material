var http    = require("http"),
    express = require("express"),
    faye    = require('faye'),
    app     = express(),
    server  = http.createServer(app);
  
// configuration
var port         = 8000,
    pubdir       = "./public",
    fayeSettings = {
      "mount": "/channel",
      "timeout": 45
    };

// Create Bayeux Server
var bayeux = new faye.NodeAdapter(fayeSettings);
  
app.configure(function() {
  // Set Public Directory
  app.use(express.static(pubdir));
});
      
// Start Servers
console.log("Starting Bayeux Server at " + fayeSettings["mount"]);
bayeux.attach(server);
console.log("Starting Server on " + port);
server.listen(port);
