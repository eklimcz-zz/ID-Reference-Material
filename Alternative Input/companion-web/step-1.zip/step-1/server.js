var http    = require("http"),
    express = require("express"),
    app     = express(),
    server  = http.createServer(app);
    
// configuration
var port    = 8000,
    pubdir  = "./public"; 

app.configure(function() {
  // Set Public Directory
  app.use(express.static(pubdir));
});
      
// Start Server
console.log("Starting Server on " + port);
server.listen(port);