# Second Screen Web App: Step 1 - Build A Simple Server.

## Minimum Requirements
* Navigation via terminal/cmd prompt 
* Familiarity with node & npm
* Browsers supported/tested
  * IE9+
  * Chrome
  * Firefox
  * Safari

## Step 1: Install
Download [node.js](http://nodejs.org/ "Node.js"). 

If you are running Windows download node.js [for Windows](http://nodejs.org/dist/v0.10.20/node-v0.10.20-x86.msi). 

##Step 2: Setup
Once you have installed nodejs, open a terminal or *Node.js command prompt* on Windows. Then navigate to the `/step-1` root directory (the unzipped folder location), and execute the following command:

    npm install

This will install all of the node dependencies listed in the accompanying `package.json` file

Then execute the following command to start the node server:

    node server

##Step 3: Browse App
Open a browser and navigate to [http://localhost:8000](http://localhost:8000). To verifiy the example is working, the primary window (localhost:8000 window/tab opened) should contain a message "Hello World!".