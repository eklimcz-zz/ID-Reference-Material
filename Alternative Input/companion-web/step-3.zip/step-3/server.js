var os      = require("os"),
    http    = require("http"),
    express = require("express"),
    faye    = require('faye'),
    app     = express(),
    server  = http.createServer(app),
    networks = os.networkInterfaces(),
    sessions = [];
  
// Helper Methods
var ip = function(version, interfaces) {
  version = version || "IPv4";
  interfaces = interfaces || ["Ethernet", "en0", "en1", "en2", "en3", "en4", "en5", "Wi-Fi"];

  for(var i = 0; i < interfaces.length; ++i) {
    if(interfaces[i] in networks) {
      detail = networks[interfaces[i]].filter(function(el){ return !el.internal && el.family === version; });
      if(detail && detail.length > 0) {
        // Brackets are necessary for use in browser
        ip = detail[0].family === "IPv6" ? ("[" + detail[0].address + "]") : detail[0].address;
        return {address:ip, version:version};
      }
    }
  }
  return {address:null, version:version};
};

var getToken = function(length) {
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  var rand = "";
  for (var i = 0; i < length; i++) {
    var pos = Math.floor(Math.random() * chars.length);
    rand += chars.substring(pos, pos + 1);
  }
  return rand;
};

// Configuration
var port         = 8000,
    host         = ip("IPv4").address + ":" + port,
    pubdir       = "./public",
    companion    = pubdir + "/secondary.html",
    fayeSettings = {
      "mount": "/channel",
      "timeout": 45
    };

// Create Bayeux Server
var bayeux = new faye.NodeAdapter(fayeSettings);

app.configure(function() {
  // Set Public Directory
  app.use(express.static(pubdir));
});

// Validate Session Channel
app.param(":channel", function validateChannel(req, res, next, channel) {
  if(channel !== null && channel !== undefined && channel.length === 3 && sessions.indexOf(channel.toUpperCase()) > -1) {
    req.channel = channel.toUpperCase();
    next();
  } else {
    next(new Error("ip[" + req.ip + "] requested invalid channel: " + channel));
  }
});

// Respond to Secondary GET Request
app.get('/:channel', function(req, res, next) {
  if(!req.channel) {
    next();
  } else {
    res.sendfile(companion);
  }
});

// Respond to Session POST Request
app.post('/session', function(req, res, next) {
  var token   = getToken(3).toUpperCase(),
      session = {
          channel: token,
          url: "//" + host + "/" + token,
          mount: "//" + host + fayeSettings.mount
        };
        
  sessions.push(session.channel);

  // Post Response
  res.status(201)
     .json(session)
     .end();
});

// Start Servers
console.log("Starting Bayeux Server at " + fayeSettings["mount"]);
bayeux.attach(server);
console.log("Starting Server on " + port);
server.listen(port);
